This is a tool for waking a computer using the Wake-on-LAN protocol. Just unzip the three .py files to a directory.
Then run:

    chmod +x magic_on.py

inside the directory. Then run the program!